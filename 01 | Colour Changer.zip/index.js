var input = document.getElementById("input");
var container = document.getElementById("Container");

function changeColor(){
    container.style.backgroundColor = input.value;

}